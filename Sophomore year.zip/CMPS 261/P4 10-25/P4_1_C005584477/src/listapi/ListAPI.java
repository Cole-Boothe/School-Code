package listapi;

public class ListAPI {

    public static void main(String[] args) {
        new TestMyArrayList();
        System.out.println();
        System.out.println();
        new TestMyLinkedList();
        System.out.println();
        new TestGenericQueue();
        System.out.println();
        new TestGenericStack();
        System.out.println();
        
    }
}
